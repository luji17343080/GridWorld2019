public class HelloWorld {
  String str;
  public void hello() {
    str = "Hello World!";
  }
  public String getStr() {
    return str;
  }
  public static void main(String []args) {
  	System.out.printf("Hello World!");
  }
}
